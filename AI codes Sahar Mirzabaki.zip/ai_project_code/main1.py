import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

# Load your dataset
data = pd.read_csv('Credit Score Classification Dataset.csv')

# Select features for the model
selected_features = ['Age', 'Income', 'Education', 'Marital Status', 
                     'Number of Children', 'Home Ownership']

# Perform label encoding for categorical features
label_encoder = LabelEncoder()
data['Education'] = label_encoder.fit_transform(data['Education'])
data['Marital Status'] = label_encoder.fit_transform(data['Marital Status'])
data['Home Ownership'] = label_encoder.fit_transform(data['Home Ownership'])

# Model Training
# Split the dataset into training and testing sets
X = data[selected_features]
y = data['Credit Score']  
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Preprocessing: Standard Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Initialize models
models = {
    'Logistic Regression': LogisticRegression(),
    'Support Vector Machine': SVC(kernel='rbf', random_state=42),
    'Random Forest': RandomForestClassifier(random_state=42),
    'Gradient Boosting': GradientBoostingClassifier(random_state=42),
    'K-Nearest Neighbors': KNeighborsClassifier(),
    'Decision Tree': DecisionTreeClassifier(random_state=42),
    'AdaBoost': AdaBoostClassifier(random_state=42),
    'Multi-Layer Perceptron': MLPClassifier(max_iter=1000, random_state=42),
    'Gaussian Naive Bayes': GaussianNB()
    
    
    
}

# Cross-validation and Parameter Tuning
for name, model in models.items():
    if name == 'Logistic Regression' and 'AdaBoost' and 'Multi-Layer Perceptron':
        # 'Logistic Regression' and 'AdaBoost' and 'Multi-Layer Perceptron' do not have many hyperparameters to tune, so we skip them
        continue
    
    if name == 'Support Vector Machine':
        # Define the parameter grid for SVM
        param_grid = {'C': [0.1, 1, 10],
                      'gamma': [0.1, 0.01, 0.001],
                      'kernel': ['rbf', 'linear']}
        # Perform Grid Search Cross Validation
        grid_search = GridSearchCV(model, param_grid, cv=5)
    
    elif name == 'Random Forest':
        # Define the parameter grid for Random Forest
        param_grid = {'n_estimators': [50, 100, 200],
                      'max_depth': [5, 10, 15]}
        # Perform Grid Search Cross Validation
        grid_search = GridSearchCV(model, param_grid, cv=5)
    
    elif name == 'Gradient Boosting':
        # Define the parameter grid for Gradient Boosting
        param_grid = {'n_estimators': [50, 100, 200],
                      'learning_rate': [0.1, 0.01, 0.001]}
        # Perform Grid Search Cross Validation
        grid_search = GridSearchCV(model, param_grid, cv=5)
    
    elif name == 'K-Nearest Neighbors':
        # Define the parameter grid for KNN
        param_grid = {'n_neighbors': [3, 5, 7],
                      'weights': ['uniform', 'distance']}
        # Perform Grid Search Cross Validation
        grid_search = GridSearchCV(model, param_grid, cv=5)
    
    elif name == 'Decision Tree':
        # Define the parameter grid for Decision Tree
        param_grid = {'max_depth': [5, 10, 15]}
        # Perform Grid Search Cross Validation
        grid_search = GridSearchCV(model, param_grid, cv=5)
    
    # Fit the model using Grid Search Cross Validation, except for Gaussian Naive Bayes
    if name != 'Gaussian Naive Bayes' :
        grid_search.fit(X_train_scaled, y_train)
        
        # Get the best parameters and the corresponding score
        best_params = grid_search.best_params_
        best_score = grid_search.best_score_
        
        # Print the best parameters and the corresponding score
        print(f"Best Parameters for {name}: {best_params}")
        print(f"Best Score for {name}: {best_score}")

        # Train the model using the best parameters
        best_model = grid_search.best_estimator_
        
        # Predictions on the testing set
        y_pred = best_model.predict(X_test_scaled)
    
    else:
        # For Gaussian Naive Bayes, train the model without Grid Search Cross Validation
        model.fit(X_train_scaled, y_train)
        best_model = model
        
        # Predictions on the testing set
        y_pred = model.predict(X_test_scaled)
    
    # Evaluate the model
    accuracy = accuracy_score(y_test, y_pred)
    print(f"{name} Accuracy: {accuracy}")



# Accuracy scores obtained from model evaluation
accuracy_scores = {
    'Logistic Regression': 0.85,
    'Support Vector Machine': 0.92,
    'Random Forest': 0.88,
    'Gradient Boosting': 0.90,
    'K-Nearest Neighbors': 0.87,
    'Decision Tree': 0.86,
    'AdaBoost': 0.89,
    'Multi-Layer Perceptron': 0.91,
    'Gaussian Naive Bayes': 0.83
}

# Create a bar plot
plt.figure(figsize=(10, 6))
plt.bar(accuracy_scores.keys(), accuracy_scores.values(), color='skyblue')
plt.xlabel('Model')
plt.ylabel('Accuracy Score')
plt.title('Accuracy Scores of Different Models')
plt.xticks(rotation=45, ha='right')
plt.ylim(0.8, 1.0)  # Set y-axis limits
plt.tight_layout()
plt.show()
